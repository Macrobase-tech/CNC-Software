﻿namespace GrblPlotter
{
    partial class ControlCoordSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSelect6 = new System.Windows.Forms.Button();
            this.btnSelect5 = new System.Windows.Forms.Button();
            this.btnSelect4 = new System.Windows.Forms.Button();
            this.btnSelect3 = new System.Windows.Forms.Button();
            this.btnSelect2 = new System.Windows.Forms.Button();
            this.btnSelect1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.gB_offset = new System.Windows.Forms.GroupBox();
            this.lblOffset6 = new System.Windows.Forms.Label();
            this.lblOffset5 = new System.Windows.Forms.Label();
            this.lblOffset4 = new System.Windows.Forms.Label();
            this.lblOffset3 = new System.Windows.Forms.Label();
            this.lblOffset2 = new System.Windows.Forms.Label();
            this.lblOffset1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSetW6 = new System.Windows.Forms.Button();
            this.btnSetW5 = new System.Windows.Forms.Button();
            this.btnSetW4 = new System.Windows.Forms.Button();
            this.btnSetW3 = new System.Windows.Forms.Button();
            this.btnSetW2 = new System.Windows.Forms.Button();
            this.btnSetW1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnSetM6 = new System.Windows.Forms.Button();
            this.btnSetM5 = new System.Windows.Forms.Button();
            this.btnSetM4 = new System.Windows.Forms.Button();
            this.btnSetM3 = new System.Windows.Forms.Button();
            this.btnSetM2 = new System.Windows.Forms.Button();
            this.btnSetM1 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnSetC6 = new System.Windows.Forms.Button();
            this.btnSetC5 = new System.Windows.Forms.Button();
            this.btnSetC4 = new System.Windows.Forms.Button();
            this.btnSetC3 = new System.Windows.Forms.Button();
            this.btnSetC2 = new System.Windows.Forms.Button();
            this.btnSetC1 = new System.Windows.Forms.Button();
            this.gB_G28 = new System.Windows.Forms.GroupBox();
            this.lblG30 = new System.Windows.Forms.Label();
            this.btnG30Set = new System.Windows.Forms.Button();
            this.btnG30Move = new System.Windows.Forms.Button();
            this.lblG28 = new System.Windows.Forms.Label();
            this.btnG28Set = new System.Windows.Forms.Button();
            this.btnG28Move = new System.Windows.Forms.Button();
            this.gB_G92 = new System.Windows.Forms.GroupBox();
            this.btnG92Off = new System.Windows.Forms.Button();
            this.lblG92 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.gB_G38 = new System.Windows.Forms.GroupBox();
            this.btnG49 = new System.Windows.Forms.Button();
            this.btnG43 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTLO = new System.Windows.Forms.Label();
            this.lblPRB = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            this.gB_offset.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gB_G28.SuspendLayout();
            this.gB_G92.SuspendLayout();
            this.gB_G38.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSelect6);
            this.groupBox1.Controls.Add(this.btnSelect5);
            this.groupBox1.Controls.Add(this.btnSelect4);
            this.groupBox1.Controls.Add(this.btnSelect3);
            this.groupBox1.Controls.Add(this.btnSelect2);
            this.groupBox1.Controls.Add(this.btnSelect1);
            this.groupBox1.Location = new System.Drawing.Point(4, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(59, 160);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select";
            // 
            // btnSelect6
            // 
            this.btnSelect6.Location = new System.Drawing.Point(4, 136);
            this.btnSelect6.Name = "btnSelect6";
            this.btnSelect6.Size = new System.Drawing.Size(50, 21);
            this.btnSelect6.TabIndex = 5;
            this.btnSelect6.Text = "6) G59";
            this.btnSelect6.UseVisualStyleBackColor = true;
            this.btnSelect6.Click += new System.EventHandler(this.BtnSelect6_Click);
            // 
            // btnSelect5
            // 
            this.btnSelect5.Location = new System.Drawing.Point(4, 112);
            this.btnSelect5.Name = "btnSelect5";
            this.btnSelect5.Size = new System.Drawing.Size(50, 21);
            this.btnSelect5.TabIndex = 4;
            this.btnSelect5.Text = "5) G58";
            this.btnSelect5.UseVisualStyleBackColor = true;
            this.btnSelect5.Click += new System.EventHandler(this.BtnSelect5_Click);
            // 
            // btnSelect4
            // 
            this.btnSelect4.Location = new System.Drawing.Point(4, 88);
            this.btnSelect4.Name = "btnSelect4";
            this.btnSelect4.Size = new System.Drawing.Size(50, 21);
            this.btnSelect4.TabIndex = 3;
            this.btnSelect4.Text = "4) G57";
            this.btnSelect4.UseVisualStyleBackColor = true;
            this.btnSelect4.Click += new System.EventHandler(this.BtnSelect4_Click);
            // 
            // btnSelect3
            // 
            this.btnSelect3.Location = new System.Drawing.Point(4, 64);
            this.btnSelect3.Name = "btnSelect3";
            this.btnSelect3.Size = new System.Drawing.Size(50, 21);
            this.btnSelect3.TabIndex = 2;
            this.btnSelect3.Text = "3) G56";
            this.btnSelect3.UseVisualStyleBackColor = true;
            this.btnSelect3.Click += new System.EventHandler(this.BtnSelect3_Click);
            // 
            // btnSelect2
            // 
            this.btnSelect2.Location = new System.Drawing.Point(4, 40);
            this.btnSelect2.Name = "btnSelect2";
            this.btnSelect2.Size = new System.Drawing.Size(50, 21);
            this.btnSelect2.TabIndex = 1;
            this.btnSelect2.Text = "2) G55";
            this.btnSelect2.UseVisualStyleBackColor = true;
            this.btnSelect2.Click += new System.EventHandler(this.BtnSelect2_Click);
            // 
            // btnSelect1
            // 
            this.btnSelect1.Location = new System.Drawing.Point(4, 16);
            this.btnSelect1.Name = "btnSelect1";
            this.btnSelect1.Size = new System.Drawing.Size(50, 21);
            this.btnSelect1.TabIndex = 0;
            this.btnSelect1.Text = "1) G54";
            this.btnSelect1.UseVisualStyleBackColor = true;
            this.btnSelect1.Click += new System.EventHandler(this.BtnSelect1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(429, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select coordinate system 1 to 6 (G54 - G59)\r\nSet Work or Marker position as new o" +
    "rigin in desired coordinate system (G10 L2 Px X Y Z)";
            // 
            // gB_offset
            // 
            this.gB_offset.Controls.Add(this.lblOffset6);
            this.gB_offset.Controls.Add(this.lblOffset5);
            this.gB_offset.Controls.Add(this.lblOffset4);
            this.gB_offset.Controls.Add(this.lblOffset3);
            this.gB_offset.Controls.Add(this.lblOffset2);
            this.gB_offset.Controls.Add(this.lblOffset1);
            this.gB_offset.Location = new System.Drawing.Point(250, 58);
            this.gB_offset.Name = "gB_offset";
            this.gB_offset.Size = new System.Drawing.Size(200, 160);
            this.gB_offset.TabIndex = 2;
            this.gB_offset.TabStop = false;
            this.gB_offset.Text = "Actual offsets X, Y, Z (A, B, C)";
            // 
            // lblOffset6
            // 
            this.lblOffset6.AutoSize = true;
            this.lblOffset6.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffset6.Location = new System.Drawing.Point(6, 142);
            this.lblOffset6.Name = "lblOffset6";
            this.lblOffset6.Size = new System.Drawing.Size(61, 11);
            this.lblOffset6.TabIndex = 5;
            this.lblOffset6.Text = "Offset 6";
            // 
            // lblOffset5
            // 
            this.lblOffset5.AutoSize = true;
            this.lblOffset5.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffset5.Location = new System.Drawing.Point(6, 118);
            this.lblOffset5.Name = "lblOffset5";
            this.lblOffset5.Size = new System.Drawing.Size(61, 11);
            this.lblOffset5.TabIndex = 4;
            this.lblOffset5.Text = "Offset 5";
            // 
            // lblOffset4
            // 
            this.lblOffset4.AutoSize = true;
            this.lblOffset4.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffset4.Location = new System.Drawing.Point(6, 94);
            this.lblOffset4.Name = "lblOffset4";
            this.lblOffset4.Size = new System.Drawing.Size(61, 11);
            this.lblOffset4.TabIndex = 3;
            this.lblOffset4.Text = "Offset 4";
            // 
            // lblOffset3
            // 
            this.lblOffset3.AutoSize = true;
            this.lblOffset3.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffset3.Location = new System.Drawing.Point(6, 70);
            this.lblOffset3.Name = "lblOffset3";
            this.lblOffset3.Size = new System.Drawing.Size(61, 11);
            this.lblOffset3.TabIndex = 2;
            this.lblOffset3.Text = "Offset 3";
            // 
            // lblOffset2
            // 
            this.lblOffset2.AutoSize = true;
            this.lblOffset2.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffset2.Location = new System.Drawing.Point(6, 46);
            this.lblOffset2.Name = "lblOffset2";
            this.lblOffset2.Size = new System.Drawing.Size(61, 11);
            this.lblOffset2.TabIndex = 1;
            this.lblOffset2.Text = "Offset 2";
            // 
            // lblOffset1
            // 
            this.lblOffset1.AutoSize = true;
            this.lblOffset1.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffset1.Location = new System.Drawing.Point(6, 22);
            this.lblOffset1.Name = "lblOffset1";
            this.lblOffset1.Size = new System.Drawing.Size(61, 11);
            this.lblOffset1.TabIndex = 0;
            this.lblOffset1.Text = "Offset 1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSetW6);
            this.groupBox3.Controls.Add(this.btnSetW5);
            this.groupBox3.Controls.Add(this.btnSetW4);
            this.groupBox3.Controls.Add(this.btnSetW3);
            this.groupBox3.Controls.Add(this.btnSetW2);
            this.groupBox3.Controls.Add(this.btnSetW1);
            this.groupBox3.Location = new System.Drawing.Point(66, 58);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(60, 160);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Work P.";
            // 
            // btnSetW6
            // 
            this.btnSetW6.Location = new System.Drawing.Point(4, 136);
            this.btnSetW6.Name = "btnSetW6";
            this.btnSetW6.Size = new System.Drawing.Size(50, 21);
            this.btnSetW6.TabIndex = 5;
            this.btnSetW6.Text = "set 6";
            this.btnSetW6.UseVisualStyleBackColor = true;
            this.btnSetW6.Click += new System.EventHandler(this.BtnSet6_Click);
            // 
            // btnSetW5
            // 
            this.btnSetW5.Location = new System.Drawing.Point(4, 112);
            this.btnSetW5.Name = "btnSetW5";
            this.btnSetW5.Size = new System.Drawing.Size(50, 21);
            this.btnSetW5.TabIndex = 4;
            this.btnSetW5.Text = "set 5";
            this.btnSetW5.UseVisualStyleBackColor = true;
            this.btnSetW5.Click += new System.EventHandler(this.BtnSet5_Click);
            // 
            // btnSetW4
            // 
            this.btnSetW4.Location = new System.Drawing.Point(4, 88);
            this.btnSetW4.Name = "btnSetW4";
            this.btnSetW4.Size = new System.Drawing.Size(50, 21);
            this.btnSetW4.TabIndex = 3;
            this.btnSetW4.Text = "set 4";
            this.btnSetW4.UseVisualStyleBackColor = true;
            this.btnSetW4.Click += new System.EventHandler(this.BtnSet4_Click);
            // 
            // btnSetW3
            // 
            this.btnSetW3.Location = new System.Drawing.Point(4, 64);
            this.btnSetW3.Name = "btnSetW3";
            this.btnSetW3.Size = new System.Drawing.Size(50, 21);
            this.btnSetW3.TabIndex = 2;
            this.btnSetW3.Text = "set 3";
            this.btnSetW3.UseVisualStyleBackColor = true;
            this.btnSetW3.Click += new System.EventHandler(this.BtnSet3_Click);
            // 
            // btnSetW2
            // 
            this.btnSetW2.Location = new System.Drawing.Point(4, 40);
            this.btnSetW2.Name = "btnSetW2";
            this.btnSetW2.Size = new System.Drawing.Size(50, 21);
            this.btnSetW2.TabIndex = 1;
            this.btnSetW2.Text = "set 2";
            this.btnSetW2.UseVisualStyleBackColor = true;
            this.btnSetW2.Click += new System.EventHandler(this.BtnSet2_Click);
            // 
            // btnSetW1
            // 
            this.btnSetW1.Location = new System.Drawing.Point(4, 16);
            this.btnSetW1.Name = "btnSetW1";
            this.btnSetW1.Size = new System.Drawing.Size(50, 21);
            this.btnSetW1.TabIndex = 0;
            this.btnSetW1.Text = "set 1";
            this.btnSetW1.UseVisualStyleBackColor = true;
            this.btnSetW1.Click += new System.EventHandler(this.BtnSet1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnSetM6);
            this.groupBox4.Controls.Add(this.btnSetM5);
            this.groupBox4.Controls.Add(this.btnSetM4);
            this.groupBox4.Controls.Add(this.btnSetM3);
            this.groupBox4.Controls.Add(this.btnSetM2);
            this.groupBox4.Controls.Add(this.btnSetM1);
            this.groupBox4.Location = new System.Drawing.Point(129, 58);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(60, 160);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Marker";
            // 
            // btnSetM6
            // 
            this.btnSetM6.Location = new System.Drawing.Point(4, 136);
            this.btnSetM6.Name = "btnSetM6";
            this.btnSetM6.Size = new System.Drawing.Size(50, 21);
            this.btnSetM6.TabIndex = 5;
            this.btnSetM6.Text = "set 6";
            this.btnSetM6.UseVisualStyleBackColor = true;
            this.btnSetM6.Click += new System.EventHandler(this.BtnSetM6_Click);
            // 
            // btnSetM5
            // 
            this.btnSetM5.Location = new System.Drawing.Point(4, 112);
            this.btnSetM5.Name = "btnSetM5";
            this.btnSetM5.Size = new System.Drawing.Size(50, 21);
            this.btnSetM5.TabIndex = 4;
            this.btnSetM5.Text = "set 5";
            this.btnSetM5.UseVisualStyleBackColor = true;
            this.btnSetM5.Click += new System.EventHandler(this.BtnSetM5_Click);
            // 
            // btnSetM4
            // 
            this.btnSetM4.Location = new System.Drawing.Point(4, 88);
            this.btnSetM4.Name = "btnSetM4";
            this.btnSetM4.Size = new System.Drawing.Size(50, 21);
            this.btnSetM4.TabIndex = 3;
            this.btnSetM4.Text = "set 4";
            this.btnSetM4.UseVisualStyleBackColor = true;
            this.btnSetM4.Click += new System.EventHandler(this.BtnSetM4_Click);
            // 
            // btnSetM3
            // 
            this.btnSetM3.Location = new System.Drawing.Point(4, 64);
            this.btnSetM3.Name = "btnSetM3";
            this.btnSetM3.Size = new System.Drawing.Size(50, 21);
            this.btnSetM3.TabIndex = 2;
            this.btnSetM3.Text = "set 3";
            this.btnSetM3.UseVisualStyleBackColor = true;
            this.btnSetM3.Click += new System.EventHandler(this.BtnSetM3_Click);
            // 
            // btnSetM2
            // 
            this.btnSetM2.Location = new System.Drawing.Point(4, 40);
            this.btnSetM2.Name = "btnSetM2";
            this.btnSetM2.Size = new System.Drawing.Size(50, 21);
            this.btnSetM2.TabIndex = 1;
            this.btnSetM2.Text = "set 2";
            this.btnSetM2.UseVisualStyleBackColor = true;
            this.btnSetM2.Click += new System.EventHandler(this.BtnSetM2_Click);
            // 
            // btnSetM1
            // 
            this.btnSetM1.Location = new System.Drawing.Point(4, 16);
            this.btnSetM1.Name = "btnSetM1";
            this.btnSetM1.Size = new System.Drawing.Size(50, 21);
            this.btnSetM1.TabIndex = 0;
            this.btnSetM1.Text = "set 1";
            this.btnSetM1.UseVisualStyleBackColor = true;
            this.btnSetM1.Click += new System.EventHandler(this.BtnSetM1_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnSetC6);
            this.groupBox5.Controls.Add(this.btnSetC5);
            this.groupBox5.Controls.Add(this.btnSetC4);
            this.groupBox5.Controls.Add(this.btnSetC3);
            this.groupBox5.Controls.Add(this.btnSetC2);
            this.groupBox5.Controls.Add(this.btnSetC1);
            this.groupBox5.Location = new System.Drawing.Point(190, 58);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(60, 160);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Set 0";
            // 
            // btnSetC6
            // 
            this.btnSetC6.Location = new System.Drawing.Point(4, 136);
            this.btnSetC6.Name = "btnSetC6";
            this.btnSetC6.Size = new System.Drawing.Size(50, 21);
            this.btnSetC6.TabIndex = 5;
            this.btnSetC6.Text = "clear 6";
            this.btnSetC6.UseVisualStyleBackColor = true;
            this.btnSetC6.Click += new System.EventHandler(this.BtnSetC6_Click);
            // 
            // btnSetC5
            // 
            this.btnSetC5.Location = new System.Drawing.Point(4, 112);
            this.btnSetC5.Name = "btnSetC5";
            this.btnSetC5.Size = new System.Drawing.Size(50, 21);
            this.btnSetC5.TabIndex = 4;
            this.btnSetC5.Text = "clear 5";
            this.btnSetC5.UseVisualStyleBackColor = true;
            this.btnSetC5.Click += new System.EventHandler(this.BtnSetC5_Click);
            // 
            // btnSetC4
            // 
            this.btnSetC4.Location = new System.Drawing.Point(4, 88);
            this.btnSetC4.Name = "btnSetC4";
            this.btnSetC4.Size = new System.Drawing.Size(50, 21);
            this.btnSetC4.TabIndex = 3;
            this.btnSetC4.Text = "clear 4";
            this.btnSetC4.UseVisualStyleBackColor = true;
            this.btnSetC4.Click += new System.EventHandler(this.BtnSetC4_Click);
            // 
            // btnSetC3
            // 
            this.btnSetC3.Location = new System.Drawing.Point(4, 64);
            this.btnSetC3.Name = "btnSetC3";
            this.btnSetC3.Size = new System.Drawing.Size(50, 21);
            this.btnSetC3.TabIndex = 2;
            this.btnSetC3.Text = "clear 3";
            this.btnSetC3.UseVisualStyleBackColor = true;
            this.btnSetC3.Click += new System.EventHandler(this.BtnSetC3_Click);
            // 
            // btnSetC2
            // 
            this.btnSetC2.Location = new System.Drawing.Point(4, 40);
            this.btnSetC2.Name = "btnSetC2";
            this.btnSetC2.Size = new System.Drawing.Size(50, 21);
            this.btnSetC2.TabIndex = 1;
            this.btnSetC2.Text = "clear 2";
            this.btnSetC2.UseVisualStyleBackColor = true;
            this.btnSetC2.Click += new System.EventHandler(this.BtnSetC2_Click);
            // 
            // btnSetC1
            // 
            this.btnSetC1.Location = new System.Drawing.Point(4, 16);
            this.btnSetC1.Name = "btnSetC1";
            this.btnSetC1.Size = new System.Drawing.Size(50, 21);
            this.btnSetC1.TabIndex = 0;
            this.btnSetC1.Text = "clear 1";
            this.btnSetC1.UseVisualStyleBackColor = true;
            this.btnSetC1.Click += new System.EventHandler(this.BtnSetC1_Click);
            // 
            // gB_G28
            // 
            this.gB_G28.Controls.Add(this.lblG30);
            this.gB_G28.Controls.Add(this.btnG30Set);
            this.gB_G28.Controls.Add(this.btnG30Move);
            this.gB_G28.Controls.Add(this.lblG28);
            this.gB_G28.Controls.Add(this.btnG28Set);
            this.gB_G28.Controls.Add(this.btnG28Move);
            this.gB_G28.Location = new System.Drawing.Point(4, 220);
            this.gB_G28.Name = "gB_G28";
            this.gB_G28.Size = new System.Drawing.Size(446, 66);
            this.gB_G28.TabIndex = 8;
            this.gB_G28.TabStop = false;
            this.gB_G28.Text = "Go to/Set Predefined Position in machine coordinates";
            // 
            // lblG30
            // 
            this.lblG30.AutoSize = true;
            this.lblG30.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblG30.Location = new System.Drawing.Point(252, 45);
            this.lblG30.Name = "lblG30";
            this.lblG30.Size = new System.Drawing.Size(89, 11);
            this.lblG30.TabIndex = 10;
            this.lblG30.Text = "Position G30";
            // 
            // btnG30Set
            // 
            this.btnG30Set.Location = new System.Drawing.Point(91, 39);
            this.btnG30Set.Name = "btnG30Set";
            this.btnG30Set.Size = new System.Drawing.Size(81, 21);
            this.btnG30Set.TabIndex = 9;
            this.btnG30Set.Text = "G30.1 set";
            this.btnG30Set.UseVisualStyleBackColor = true;
            this.btnG30Set.Click += new System.EventHandler(this.BtnG30Set_Click);
            // 
            // btnG30Move
            // 
            this.btnG30Move.Location = new System.Drawing.Point(4, 39);
            this.btnG30Move.Name = "btnG30Move";
            this.btnG30Move.Size = new System.Drawing.Size(81, 21);
            this.btnG30Move.TabIndex = 8;
            this.btnG30Move.Text = "G30 move to";
            this.btnG30Move.UseVisualStyleBackColor = true;
            this.btnG30Move.Click += new System.EventHandler(this.BtnG30Move_Click);
            // 
            // lblG28
            // 
            this.lblG28.AutoSize = true;
            this.lblG28.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblG28.Location = new System.Drawing.Point(252, 22);
            this.lblG28.Name = "lblG28";
            this.lblG28.Size = new System.Drawing.Size(89, 11);
            this.lblG28.TabIndex = 6;
            this.lblG28.Text = "Position G28";
            // 
            // btnG28Set
            // 
            this.btnG28Set.Location = new System.Drawing.Point(91, 16);
            this.btnG28Set.Name = "btnG28Set";
            this.btnG28Set.Size = new System.Drawing.Size(81, 21);
            this.btnG28Set.TabIndex = 7;
            this.btnG28Set.Text = "G28.1 set";
            this.btnG28Set.UseVisualStyleBackColor = true;
            this.btnG28Set.Click += new System.EventHandler(this.BtnG28Set_Click);
            // 
            // btnG28Move
            // 
            this.btnG28Move.Location = new System.Drawing.Point(4, 16);
            this.btnG28Move.Name = "btnG28Move";
            this.btnG28Move.Size = new System.Drawing.Size(81, 21);
            this.btnG28Move.TabIndex = 6;
            this.btnG28Move.Text = "G28 move to";
            this.btnG28Move.UseVisualStyleBackColor = true;
            this.btnG28Move.Click += new System.EventHandler(this.BtnG28Move_Click);
            // 
            // gB_G92
            // 
            this.gB_G92.Controls.Add(this.btnG92Off);
            this.gB_G92.Controls.Add(this.lblG92);
            this.gB_G92.Location = new System.Drawing.Point(4, 287);
            this.gB_G92.Name = "gB_G92";
            this.gB_G92.Size = new System.Drawing.Size(446, 44);
            this.gB_G92.TabIndex = 9;
            this.gB_G92.TabStop = false;
            this.gB_G92.Text = "G92 Coordinate System Offset";
            // 
            // btnG92Off
            // 
            this.btnG92Off.Location = new System.Drawing.Point(4, 16);
            this.btnG92Off.Name = "btnG92Off";
            this.btnG92Off.Size = new System.Drawing.Size(236, 21);
            this.btnG92Off.TabIndex = 11;
            this.btnG92Off.Text = "G92.1 - turn off G92 offsets and reset";
            this.btnG92Off.UseVisualStyleBackColor = true;
            this.btnG92Off.Click += new System.EventHandler(this.BtnG92Off_Click);
            // 
            // lblG92
            // 
            this.lblG92.AutoSize = true;
            this.lblG92.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblG92.Location = new System.Drawing.Point(252, 22);
            this.lblG92.Name = "lblG92";
            this.lblG92.Size = new System.Drawing.Size(75, 11);
            this.lblG92.TabIndex = 11;
            this.lblG92.Text = "Offset G92";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Coordinate System";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(250, 403);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(199, 23);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "Update values";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // gB_G38
            // 
            this.gB_G38.Controls.Add(this.btnG49);
            this.gB_G38.Controls.Add(this.btnG43);
            this.gB_G38.Controls.Add(this.label3);
            this.gB_G38.Controls.Add(this.lblTLO);
            this.gB_G38.Controls.Add(this.lblPRB);
            this.gB_G38.Location = new System.Drawing.Point(4, 333);
            this.gB_G38.Name = "gB_G38";
            this.gB_G38.Size = new System.Drawing.Size(446, 66);
            this.gB_G38.TabIndex = 12;
            this.gB_G38.TabStop = false;
            this.gB_G38.Text = "Probing and Tool length offset (TLO)";
            // 
            // btnG49
            // 
            this.btnG49.Location = new System.Drawing.Point(104, 39);
            this.btnG49.Name = "btnG49";
            this.btnG49.Size = new System.Drawing.Size(94, 21);
            this.btnG49.TabIndex = 15;
            this.btnG49.Text = "G49 cancel TLO";
            this.btnG49.UseVisualStyleBackColor = true;
            this.btnG49.Click += new System.EventHandler(this.BtnG49_Click);
            // 
            // btnG43
            // 
            this.btnG43.Location = new System.Drawing.Point(4, 39);
            this.btnG43.Name = "btnG43";
            this.btnG43.Size = new System.Drawing.Size(94, 21);
            this.btnG43.TabIndex = 11;
            this.btnG43.Text = "G43.1 set TLO";
            this.toolTip1.SetToolTip(this.btnG43, "Set TLO with current work coordinate");
            this.btnG43.UseVisualStyleBackColor = true;
            this.btnG43.Click += new System.EventHandler(this.BtnG43_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(231, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Probing result from G38.2, G38.3, G38.4, G38.5";
            // 
            // lblTLO
            // 
            this.lblTLO.AutoSize = true;
            this.lblTLO.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTLO.Location = new System.Drawing.Point(252, 45);
            this.lblTLO.Name = "lblTLO";
            this.lblTLO.Size = new System.Drawing.Size(89, 11);
            this.lblTLO.TabIndex = 13;
            this.lblTLO.Text = "Position TLO";
            this.toolTip1.SetToolTip(this.lblTLO, "Green background indicates appölication of TLO");
            // 
            // lblPRB
            // 
            this.lblPRB.AutoSize = true;
            this.lblPRB.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPRB.Location = new System.Drawing.Point(252, 22);
            this.lblPRB.Name = "lblPRB";
            this.lblPRB.Size = new System.Drawing.Size(89, 11);
            this.lblPRB.TabIndex = 12;
            this.lblPRB.Text = "Position PRB";
            this.toolTip1.SetToolTip(this.lblPRB, "Green background indicates last probing was successful");
            // 
            // ControlCoordSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 431);
            this.Controls.Add(this.gB_G38);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gB_G92);
            this.Controls.Add(this.gB_G28);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gB_offset);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(470, 470);
            this.MinimumSize = new System.Drawing.Size(470, 470);
            this.Name = "ControlCoordSystem";
            this.Text = "Control Coordinate System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ControlCoordSystem_FormClosing);
            this.Load += new System.EventHandler(this.ControlCoordSystem_Load);
            this.groupBox1.ResumeLayout(false);
            this.gB_offset.ResumeLayout(false);
            this.gB_offset.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.gB_G28.ResumeLayout(false);
            this.gB_G28.PerformLayout();
            this.gB_G92.ResumeLayout(false);
            this.gB_G92.PerformLayout();
            this.gB_G38.ResumeLayout(false);
            this.gB_G38.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSelect6;
        private System.Windows.Forms.Button btnSelect5;
        private System.Windows.Forms.Button btnSelect4;
        private System.Windows.Forms.Button btnSelect3;
        private System.Windows.Forms.Button btnSelect2;
        private System.Windows.Forms.Button btnSelect1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gB_offset;
        private System.Windows.Forms.Label lblOffset6;
        private System.Windows.Forms.Label lblOffset5;
        private System.Windows.Forms.Label lblOffset4;
        private System.Windows.Forms.Label lblOffset3;
        private System.Windows.Forms.Label lblOffset2;
        private System.Windows.Forms.Label lblOffset1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnSetW1;
        private System.Windows.Forms.Button btnSetW6;
        private System.Windows.Forms.Button btnSetW5;
        private System.Windows.Forms.Button btnSetW4;
        private System.Windows.Forms.Button btnSetW3;
        private System.Windows.Forms.Button btnSetW2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnSetM6;
        private System.Windows.Forms.Button btnSetM5;
        private System.Windows.Forms.Button btnSetM4;
        private System.Windows.Forms.Button btnSetM3;
        private System.Windows.Forms.Button btnSetM2;
        private System.Windows.Forms.Button btnSetM1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnSetC6;
        private System.Windows.Forms.Button btnSetC5;
        private System.Windows.Forms.Button btnSetC4;
        private System.Windows.Forms.Button btnSetC3;
        private System.Windows.Forms.Button btnSetC2;
        private System.Windows.Forms.Button btnSetC1;
        private System.Windows.Forms.GroupBox gB_G28;
        private System.Windows.Forms.Label lblG30;
        private System.Windows.Forms.Button btnG30Set;
        private System.Windows.Forms.Button btnG30Move;
        private System.Windows.Forms.Label lblG28;
        private System.Windows.Forms.Button btnG28Set;
        private System.Windows.Forms.Button btnG28Move;
        private System.Windows.Forms.GroupBox gB_G92;
        private System.Windows.Forms.Button btnG92Off;
        private System.Windows.Forms.Label lblG92;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.GroupBox gB_G38;
        private System.Windows.Forms.Label lblTLO;
        private System.Windows.Forms.Label lblPRB;
        private System.Windows.Forms.Button btnG49;
        private System.Windows.Forms.Button btnG43;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}