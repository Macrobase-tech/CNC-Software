This setup installs GRBL-Plotter:
A GCode sender (not only for plotters) for up to two GRBL controller. SVG, DXF, HPGL import. 6 axis DRO.

Xloader and grbl firmwares as hex-files:
After start of GRBL-Plotter, check the "About" window for the location of the data-path, where the Firmware folder is located.
Just click on the link to open the folder.

GRBL-Plotter on GitHub:
https://github.com/svenhb/GRBL-Plotter

GRBL-Plotter website:
https://grbl-plotter.de/?setlang=en

